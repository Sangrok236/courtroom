# 법정의 모순 — AI 법정 게임 프로토타입

## 실행

Python 3.11 이상을 권장합니다.

```bash
cd courtroom_demo
uv run --with streamlit --with openai streamlit run app.py
```

또는 `pip install -r requirements.txt` 후 `streamlit run app.py`.

브라우저에서 표시된 로컬 주소로 접속합니다.

## 선택: AI 자유 대화 활성화

API 키 없이도 규칙 기반 대화와 증거 제시를 시험할 수 있습니다. OpenAI API를 연결하려면 실행 전에 환경 변수 `OPENAI_API_KEY`를 설정하세요. 선택적으로 `OPENAI_MODEL`을 지정할 수 있습니다. API 이용 요금은 별도입니다.

- 대화는 증인 답변만 생성합니다.
- 증거 제시와 정답 판정은 Python 코드가 처리합니다.
- 사건의 정답은 AI에게 전달하지 않습니다.
- 이것은 한 사건의 짧은 시연판으로, 완전한 재판이나 저장 기능은 없습니다.
